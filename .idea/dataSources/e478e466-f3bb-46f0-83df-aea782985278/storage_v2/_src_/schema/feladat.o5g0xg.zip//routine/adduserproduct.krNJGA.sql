create procedure adduserproduct(IN pname      varchar(20), IN pdesc varchar(255), IN pprice int,
                                IN pimagepath varchar(255), IN puserid int)
  BEGIN
Declare newproductid int;
set newproductid := addProduct(pname,pdesc,pprice,pimagepath);
insert into usersproduct(userid,productid)value(puserid,newproductid);
END;

