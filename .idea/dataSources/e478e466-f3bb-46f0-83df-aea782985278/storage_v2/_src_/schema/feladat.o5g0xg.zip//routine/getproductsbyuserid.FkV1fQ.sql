create procedure getproductsbyuserid(IN userid int)
  BEGIN
 select p.* from usersproduct u inner join product p on (p.id = u.productid) where u.userid = userid;
END;

