create procedure getallproducts()
  BEGIN
select * from product;
END;

