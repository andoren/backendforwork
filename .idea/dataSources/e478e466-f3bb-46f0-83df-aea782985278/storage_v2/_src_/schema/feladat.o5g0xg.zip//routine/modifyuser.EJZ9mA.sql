create procedure modifyuser(IN pusername varchar(20), IN ppassword varchar(255), IN prealname varchar(50),
                            IN prole     varchar(5), IN pemail varchar(255), IN uid int)
  BEGIN
	update user set username = pusername, password = ppassword, realname = prealname, role = prole, email = pemail where id = uid;
END;

